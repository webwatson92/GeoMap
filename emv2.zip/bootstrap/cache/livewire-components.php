<?php return array (
  'userdatatable' => 'App\\Http\\Livewire\\Userdatatable',
);