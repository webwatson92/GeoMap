<?php

return [

    "zoom_level" => 15,
    "detail_zoom_level" => 16,
    "map_center_latitude" =>env("MAP_CENTER_LATITUDE", "7.539989"),
    "map_center_longitude" =>env("MAP_CENTER_LONGITUDE", "-5.547080")

];
